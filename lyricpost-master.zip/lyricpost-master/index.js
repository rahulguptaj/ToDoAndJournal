const fetcher = new DataFetcher();
const domHandler = new DOMHandler(fetcher);